using UnityEngine;
using UnityEngine.AI;
using System.Collections;

public class AIObstacle : ObstacleBase
{
    private enum AIState { Patrol, Chase, Cooldown }
    private AIState _currentState = AIState.Patrol;

    [Header("Patrol")]
    [SerializeField] private Transform[] waypoints;
    [SerializeField] private float patrolSpeed = 2.5f;
    [SerializeField] private float waypointReachDistance = 0.3f;

    [Header("Chase")]
    [SerializeField] private float detectionRadius = 4f;
    [SerializeField] private float chaseSpeed = 4.5f;
    [SerializeField] private float loseInterestRadius = 7f;

    [Header("Cooldown")]
    [SerializeField] private float cooldownAfterChase = 2f;

    [Header("Visual Feedback")]
    [SerializeField] private Renderer bodyRenderer;
    [SerializeField] private Color patrolColor = Color.blue;
    [SerializeField] private Color chaseColor = Color.red;

    [SerializeField] private float hitCooldown = 2f;
    private bool _canHitPlayer = true;

    private int _currentWaypointIndex;
    private Transform _player;
    private float _cooldownTimer;
    private NavMeshAgent _agent;

    protected override void Start()
    {
        base.Start();

        PlayerController pc = FindFirstObjectByType<PlayerController>();
        if (pc != null)
            _player = pc.transform;

        _agent = GetComponent<NavMeshAgent>();

        if (_agent == null)
        {
            Debug.LogError("AIObstacle requires a NavMeshAgent component.");
            enabled = false;
            return;
        }

        if (bodyRenderer == null)
            bodyRenderer = GetComponentInChildren<Renderer>();

        _agent.speed = patrolSpeed;
        _agent.stoppingDistance = 0f;

        SetColor(patrolColor);
    }

    protected override void Update()
    {
        base.Update();

        if (GameManager.Instance == null ||
            GameManager.Instance.CurrentState != GameState.Playing)
            return;

        if (waypoints == null || waypoints.Length == 0)
            return;

        switch (_currentState)
        {
            case AIState.Patrol:
                UpdatePatrol();
                break;

            case AIState.Chase:
                UpdateChase();
                break;

            case AIState.Cooldown:
                UpdateCooldown();
                break;
        }
    }

    private void UpdatePatrol()
    {
        Transform target = waypoints[_currentWaypointIndex];

        _agent.speed = patrolSpeed;
        _agent.SetDestination(target.position);

        if (!_agent.pathPending &&
            _agent.remainingDistance <= waypointReachDistance)
        {
            _currentWaypointIndex =
                (_currentWaypointIndex + 1) % waypoints.Length;
        }

        if (_player != null &&
            Vector3.Distance(transform.position, _player.position) <= detectionRadius)
        {
            TransitionTo(AIState.Chase);
        }
    }

    private void UpdateChase()
    {
        if (_player == null)
        {
            TransitionTo(AIState.Cooldown);
            return;
        }

        _agent.speed = chaseSpeed;
        _agent.SetDestination(_player.position);

        if (Vector3.Distance(transform.position, _player.position) > loseInterestRadius)
        {
            TransitionTo(AIState.Cooldown);
        }
    }

    private void UpdateCooldown()
    {
        _cooldownTimer -= Time.deltaTime;

        if (_cooldownTimer <= 0f)
        {
            TransitionTo(AIState.Patrol);
        }
    }

    private void TransitionTo(AIState newState)
    {
        _currentState = newState;

        switch (newState)
        {
            case AIState.Patrol:
                _agent.speed = patrolSpeed;
                SetColor(patrolColor);
                break;

            case AIState.Chase:
                _agent.speed = chaseSpeed;
                SetColor(chaseColor);
                break;

            case AIState.Cooldown:
                _cooldownTimer = cooldownAfterChase;
                _agent.ResetPath();
                SetColor(patrolColor);
                break;
        }
    }

    private void SetColor(Color color)
    {
        if (bodyRenderer != null)
            bodyRenderer.material.color = color;
    }
    
    protected override void OnPlayerHit(Collision collision)
    {
        if (!_canHitPlayer)
            return;

        ReturnToPatrol();
        StartCoroutine(HitCooldownRoutine());
    }

    protected override void OnPlayerTriggered(Collider other)
    {
        if (!_canHitPlayer)
            return;

        ReturnToPatrol();
        StartCoroutine(HitCooldownRoutine());
    }

    private IEnumerator HitCooldownRoutine()
    {
        _canHitPlayer = false;

        TransitionTo(AIState.Cooldown);

        yield return new WaitForSeconds(hitCooldown);

        _canHitPlayer = true;
    }

    private void ReturnToPatrol()
    {
        if (_agent == null || waypoints == null || waypoints.Length == 0)
            return;

        _agent.ResetPath();

        float closestDistance = float.MaxValue;
        int closestIndex = 0;

        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] == null)
                continue;

            float distance = Vector3.Distance(
                transform.position,
                waypoints[i].position);

            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestIndex = i;
            }
        }

        _currentWaypointIndex = closestIndex;

        // Instantly return AI to nearest patrol point
        _agent.Warp(waypoints[_currentWaypointIndex].position);

        TransitionTo(AIState.Patrol);
    }

#if UNITY_EDITOR
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, loseInterestRadius);

        if (waypoints == null) return;

        Gizmos.color = Color.cyan;

        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] == null) continue;

            Gizmos.DrawSphere(waypoints[i].position, 0.2f);

            if (i + 1 < waypoints.Length && waypoints[i + 1] != null)
            {
                Gizmos.DrawLine(
                    waypoints[i].position,
                    waypoints[i + 1].position);
            }
        }
    }
#endif
}